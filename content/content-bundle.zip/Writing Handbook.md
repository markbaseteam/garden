---
Title: Writing Well
Author: Julian Shapiro
Tags: writing
---

# Ideas
## ==Step 1: Choose a Topic==
There are 5 novelty categories:

1. **Counter-intuitive**  
2. **Counter-narrative** 
3. **Shock and Awe** 
4. **Elegant Articulations** 
5. **Make someone feel seen** 

- Find your novel ideas with your curiosity, interests, and notes.
> Ideas resonate when they're wrapped in:
> 	- Stories
> 	- Analogies
> 	- Examples
> 	- Authentic Voice

- What is the best topic to write about?
	- It is the ideas that you find compelling and you want to go to the rabbit hole.
	- The ideas that you've been thinking of that bothers you.

### Choose Your Objective
- Open people's eyes by proving the status quo wrong.
- Share a solution to a tough problem.
- Make a complex topic simple/approachable.
- Tell an emotional story with a lesson
- Write something that everyone's thinking about but no one is saying.
- Identify key trends and use them to predict the future.
- Contribute original insights to a field through your research.

### Choose What Motivates Them
- Do you obsess over the topic and want others to geek it out over it too?
- Does it pursuade others?
- Does it help to solve a problem?
- Does writing this article get something off your chest?

## ==Step 2: Write an intro==
- Use a hook and tell the readers what is this about.

### Types of Hooks
- Questions - present an intriguing question
- Narratives - present a story to captivate readers emotionally and insert a twist at the end
- Research 
- Arguments - present a bold and declarative claim

An intro must accomplish these 2 things:
1. Give readers a reason to care about our hook and connect it to meaningful problems they're facing.
2. Hook readers with half of an interesting story.

- Hooks become talking points.
> Great hooks force you to write something novel.

>Tip: Turn your questions into a hook.
For example: Can you buy a cheap home equipment instead? => There's affordable home equipment that makes this possible.

> ==Anything can be interesting when framed by an intriguing question.==

### The Spine of a Good Intro
An effective intro often follows this structure:
- Establish shared context
- Surface a problem and what's at stake
- Explore the problem's significance.
- Tease a clever solution

### The Elements of a Good Intro
- It's a compelling hook.
- It tells why the idea is important.
- It's concise.
# Writing First Drafts
## ==Step 1: Start With Your Objective==
Choose your objectives at the top.

There are 2 types of ideas that comprise your outline.
	- **Supporting Points** - Which arguments are needed to make my argument?
	- **Resulting Points** - What are the implications of my argument being true?

## ==Step 2: Outline Your Ideas==

## ==Step 3: Fill the Outline==

> To uncover interesting ideas, continuously make your next point whatever interests _you_ most. Skip everything that bores you.


When ideas stop flowing, ask yourself:  

1.  How can I make this point more convincing?
2.  What are the interesting implications of what I just said?

# Rewriting
## ==1. Goal: Be understood==

To achieve clarity, know:
- What you're really saying
- Your main point
- How to make your point easier to understand

Tips to achieve clarity:
- Use simpler sentences.
- Remove abstract **phrasing**.
- Imagine that you're **writing** to a 5-year-old. 
- Provide examples.


See also:
- [[]]
---
