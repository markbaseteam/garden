---
Title: Looking for Quality in Student Writing
Author: Steve Peha
Tags: writing
---

To achieve sentence fluency, you need to:

- Vary your sentence beginnings.
- Vary your sentence length.
- Vary your sentence structure.

See also:


---
Peha, S. Looking for Quality in Student Writing. https://www.ttms.org/writing_quality/sentence_fluency.htm