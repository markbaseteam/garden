---
Title: Why Do Some People Have Cheek Dimples?
Author: Healthline, Jill Seladi-Schulman, Ph.D.
Tags: genetics
---

- Dimples are unknown if they are inherited or not.
> However, very little research has actually been done into the actual genetics of cheek dimples. It is not known if dimples are truly inherited or not.
- The inheritance of cheek dimples are unpredictable.
> Because the inheritance pattern of cheek dimples can be unpredictable, some researchers classify them as an irregular dominant trait. This means that cheek dimples are often, but not always, inherited as a dominant trait.
- Researchers classify it as an irregular dominant trait.

---
Schulman, J. (2019). Why Do Some People Have Cheek Dimples? https://www.healthline.com/health/cheek-dimples