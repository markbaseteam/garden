---
Title: Is your lead magnet killing your followers?
Author: Kieran Drew
Tags: writing
---

# Avoid These Mistakes in Your Lead Magnet
-   Too long
-   Poorly presented
-   Destroying reader relationships (more on that below)

# If You Want Your Lead Magnet to Stand Out, Do These
1. Define your audience and what you offer.
2. Avoid asking too much.
3. Solve a problem.
4. Coin a term for your framework.
5. Add social proof.
6. Make your lead magnet presentable. 
	- First impressions count.
7. Tell a story.
8. Don't forget your CTA.


See also:
- [[]]
---
