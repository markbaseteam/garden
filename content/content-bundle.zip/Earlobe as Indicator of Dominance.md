---
Title: Attached Earlobe - The Myth
Author: John H. McDonald
Tags: genetics
---

- Don't use earlobe attachments as an indicator of dominance. 
- Free and attached earlobes are not only the categories of earlobe attachments.
> Earlobes do not fall into two categories, "free" and "attached"; there is continuous variation in attachment point, from up near the ear cartilage to well below the ear. While there is probably some genetic influence on earlobe attachment point, family studies show that it does not fit the simple one-locus, two-allele myth. You should not use earlobe attachment to demonstrate basic genetics.

See also:
- [[Dimples in Inheritance]]

---
McDonald, J. (2011). Attached earlobe: The myth. https://udel.edu/~mcdonald/mythearlobe.html