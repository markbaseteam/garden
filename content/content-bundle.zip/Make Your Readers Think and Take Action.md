---
Title: I Want My Readers To...
Author: Nicolas Cole
Tags: writing
---
> I don't want readers who Like and Comment. I want readers who think & take action.

See also:
- [[]]
---
https://twitter.com/Nicolascole77/status/1522316095251632129?s=20&t=6gY0nunI3xVVOZhhlLb9kg