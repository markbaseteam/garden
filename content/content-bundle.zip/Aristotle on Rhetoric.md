---
Title: How to Use Rhetoric to Get What You Want
Author: Camille A. Langston
Tags: writing, persuasion
---

# The 3 ==Types== of Rhetorical Speech

## Forensic (Judicial Rhetoric)
- Facts and judgments about the past.
## Epideictic (Demonstrative Rhetoric)
- Proclamation about the present situation.
## Symboleutikon
- Focuses on the possibilities on the future.
# The 3 Persuasive ==Appeals==
## Ethos
- Convincing the audience with credibility.
## Logos
- Convincing the audience with logic and facts.
## Pathos
- Convincing the audience with emotion.

See also:
- [[What is a rhetoric]]
---


[Ted Ed](https://www.youtube.com/watch?v=3klMM9BkW5o)