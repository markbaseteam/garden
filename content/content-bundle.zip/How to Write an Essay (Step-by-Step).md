---
Title: Papers & Essays
Author: CrashCourse
Tags: writing, study-skills
---

# Pre-Writing Phase
- **Brain dumping** is one of the ways to get everything you know and thoughts about the topic. Then, make some questions.
- **Find your sources** at the buttom of Wikipedia.
- **Highlight** the texts that feels relevant to your argumen. Then, add some notes.
> Writing tips: 
> - If you think you don't have to write perfect, the writing will be easier for you.
> - Use a separate app for writing your first draft and for polishing it.

# 2 Stages of Editing
## 1. Content Editing
In content editing, you see the paper as a whole and you ask these following questions:
- Does each argument support the thesis?
- Does the paper have a good narrative flow?
- Is each argument properly fleshed out and backed up with research or external sources?
- What can be removed or written in a clearer, simpler way?
## 2. Technical Editing
In technical editing, you read the paper out loud and identify these things:
- Spelling and grammar mistakes
- Poorly structured sentences
- Formatting errors
- Sentences that just don't sound right

See also:
- [[]]
---
Reference:
Crash Course. (2018) https://youtu.be/KlgR1q3UQZE