---
Title: Make People Feel Smarter
Author: David Perell
Tags: writing, social-skills
---

> People who are good at conversations make the others feel smarter when they’re around them.

See also:
- [[]]
---
https://twitter.com/david_perell/status/1529280071730704385?s=20&t=6gY0nunI3xVVOZhhlLb9kg